# DFBS

Project to restore data using DFBS : Double Filtering Based Smoothing

      >>  python3 Test_DFBSmoothing.py [arguments]

## Arguments

      argv[1] : 
                
      argv[2] : 
                
      argv[3] : 
                
      argv[4] : 
                
      argv[5] : 
                
      argv[6] : 
                
      argv[7] : 
                
      argv[8] : 
                

## Running Examples

      >> python3 ....
