
This repository includes all the stuff regarding CGOMSM : Conditionally Gaussian Observed Markov Switching Model

Look at the others *readme* files for details on how to test the programs (under construction).
